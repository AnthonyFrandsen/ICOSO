(*** This section is for bug reports and feature requests only. This is NOT a help site. Do not ask help questions here. If you need help, please use stackoverflow. ***)

##### Description of the problem 


##### Three.js version

- [ ] Dev
- [ ] r82
- [ ] ...

##### Browser

- [x] All of them
- [ ] Chrome
- [ ] Firefox
- [ ] Internet Explorer

##### OS

- [x] All of them
- [ ] Windows
- [ ] Linux
- [ ] Android
- [ ] IOS

##### Hardware Requirements (graphics card, VR Device, ...)


